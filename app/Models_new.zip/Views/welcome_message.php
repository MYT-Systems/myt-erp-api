<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Welcome to CodeIgniter 4!</title>
	<meta name="description" content="The small framework with powerful features">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="google-signin-client_id" content="1052260843027-q1iiojesrmf24ajgbjpajfichlhaosj8.apps.googleusercontent.com">
	<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>

	<!-- STYLES -->
</head>
<body>

	<h1>HELLO ADMIN API</h1>
	<!-- <button id="profile" type="button">Get Profile</button>

	<div class="g-signin2" data-onsuccess="onSignIn"></div>

	<script>
		var BASE_URI = '<?=base_url();?>';
	</script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://apis.google.com/js/platform.js" async defer></script>
	<script src="<?=base_url('js/sample.js');?>"></script> -->

</body>
</html>
